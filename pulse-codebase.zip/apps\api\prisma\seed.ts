import { prisma } from '../src/lib/prisma.js';

async function seed() {
  console.log('🌱 Seeding database...');

  // Create admin user
  const admin = await prisma.user.upsert({
    where: { email: 'admin@pulse.app' },
    update: {},
    create: {
      email: 'admin@pulse.app',
      username: 'admin',
      displayName: 'Admin',
      passwordHash: '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', // "Admin123"
      role: 'ADMIN',
      emailVerified: true,
    },
  });

  // Create demo user
  const user1 = await prisma.user.upsert({
    where: { email: 'student@iitm.ac.in' },
    update: {},
    create: {
      email: 'student@iitm.ac.in',
      username: 'campus_anon',
      displayName: 'Campus Anon',
      passwordHash: '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
      college: 'IIT Madras',
      branch: 'CS',
      year: 3,
      emailVerified: true,
    },
  });

  const user2 = await prisma.user.upsert({
    where: { email: 'student@vit.ac.in' },
    update: {},
    create: {
      email: 'student@vit.ac.in',
      username: 'vit_coder',
      displayName: 'VIT Coder',
      passwordHash: '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
      college: 'VIT Vellore',
      branch: 'IT',
      year: 2,
      emailVerified: true,
    },
  });

  // Create communities
  const communities = await Promise.all([
    prisma.community.upsert({
      where: { slug: 'general' },
      update: {},
      create: { name: 'General', slug: 'general', description: 'Open forum for all topics', category: 'general', isDefault: true },
    }),
    prisma.community.upsert({
      where: { slug: 'iitm-placements' },
      update: {},
      create: { name: 'IIT Madras Placements', slug: 'iitm-placements', description: 'Placement discussions for IIT Madras', college: 'IIT Madras', category: 'placement' },
    }),
    prisma.community.upsert({
      where: { slug: 'vit-memes' },
      update: {},
      create: { name: 'VIT Memes', slug: 'vit-memes', description: 'The dankest VIT memes', college: 'VIT Vellore', category: 'memes' },
    }),
    prisma.community.upsert({
      where: { slug: 'campus-confessions' },
      update: {},
      create: { name: 'Campus Confessions', slug: 'campus-confessions', description: 'Anonymous confessions from college students', category: 'general', isDefault: true },
    }),
    prisma.community.upsert({
      where: { slug: 'tech-talk' },
      update: {},
      create: { name: 'Tech Talk', slug: 'tech-talk', description: 'Programming, tech news, and CS discussions', category: 'academic', isDefault: true },
    }),
    prisma.community.upsert({
      where: { slug: 'hostel-life' },
      update: {},
      create: { name: 'Hostel Life', slug: 'hostel-life', description: 'Everything about hostel living', category: 'hostel', isDefault: true },
    }),
  ]);

  // Join communities
  for (const community of communities) {
    for (const user of [admin, user1, user2]) {
      await prisma.communityMember.upsert({
        where: { userId_communityId: { userId: user.id, communityId: community.id } },
        update: {},
        create: { userId: user.id, communityId: community.id },
      });
    }
  }

  // Create posts
  const posts = [
    { authorId: user1.id, communityId: communities[3]!.id, content: 'I sit behind my crush in every lecture but have never said a word. Three years and counting. Send help. 😭', isAnonymous: true, tags: ['confession', 'crush'] },
    { authorId: user2.id, communityId: communities[0]!.id, content: 'Hot take: The mess food has actually gotten better this semester. The new paneer dish hits different. Anyone else noticed?', isAnonymous: false, tags: ['food', 'mess'] },
    { authorId: user1.id, communityId: communities[4]!.id, content: 'Just finished building a full-stack app with Next.js 15 and Hono. The DX is incredible compared to Express. Who else has made the switch?', isAnonymous: false, tags: ['nextjs', 'webdev'], title: 'Next.js 15 + Hono = 🔥' },
    { authorId: user2.id, communityId: communities[1]!.id, content: 'Anyone know the package for SDE-1 at Google this year? Heard it\'s insane. Also, how many DSA questions should I expect in the interview?', isAnonymous: true, tags: ['placement', 'google'] },
    { authorId: admin.id, communityId: communities[5]!.id, content: 'The WiFi in Block C has been down for 3 days now. Anyone else affected? Should we file a mass complaint?', isAnonymous: true, tags: ['wifi', 'hostel'] },
    { authorId: user1.id, communityId: communities[2]!.id, content: 'When the professor says "this is very easy" and then the entire class fails 💀\n\n*nervous laughing intensifies*', isAnonymous: true, tags: ['memes', 'exams'] },
  ];

  for (const postData of posts) {
    const post = await prisma.post.create({ data: { ...postData, score: Math.floor(Math.random() * 50) } });

    // Add some comments
    await prisma.comment.create({
      data: { authorId: user2.id, postId: post.id, content: 'This is so relatable! 😂', isAnonymous: true },
    });
    await prisma.post.update({ where: { id: post.id }, data: { commentCount: 1 } });
  }

  // Create a poll post
  await prisma.post.create({
    data: {
      authorId: user1.id,
      communityId: communities[0]!.id,
      content: 'What is the best programming language to learn in 2026?',
      title: 'Best Programming Language 2026',
      type: 'POLL',
      isAnonymous: false,
      tags: ['poll', 'programming'],
      score: 25,
      poll: {
        create: {
          options: {
            create: [
              { text: 'TypeScript', orderNum: 0 },
              { text: 'Rust', orderNum: 1 },
              { text: 'Go', orderNum: 2 },
              { text: 'Python', orderNum: 3 },
            ],
          },
        },
      },
    },
  });

  console.log('✅ Seed complete!');
  console.log(`   ${(await prisma.user.count())} users`);
  console.log(`   ${(await prisma.community.count())} communities`);
  console.log(`   ${(await prisma.post.count())} posts`);
}

seed()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
