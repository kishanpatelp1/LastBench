import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowUp, ArrowDown, MessageSquare, Share2, MoreHorizontal } from 'lucide-react';
import { cn, timeAgo, formatNumber } from '../../lib/utils';
import { api } from '../../lib/api-client';
import { useState } from 'react';
import { toast } from 'sonner';
import { Post } from '../../types';

interface PostCardProps {
  post: Post;
}

export function PostCard({ post }: PostCardProps) {
  const [optimisticScore, setOptimisticScore] = useState(post.score);
  const [optimisticVote, setOptimisticVote] = useState(post.userVote);
  const [showMenu, setShowMenu] = useState(false);

  const author = post.author;
  const community = post.community;
  const tags = post.tags ?? [];
  const poll = post.poll;

  const handleVote = async (type: 'UP' | 'DOWN') => {
    const prevScore = optimisticScore;
    const prevVote = optimisticVote;

    // Optimistic update
    if (optimisticVote === type) {
      setOptimisticScore(prevScore + (type === 'UP' ? -1 : 1));
      setOptimisticVote(null);
    } else if (optimisticVote) {
      setOptimisticScore(prevScore + (type === 'UP' ? 2 : -2));
      setOptimisticVote(type);
    } else {
      setOptimisticScore(prevScore + (type === 'UP' ? 1 : -1));
      setOptimisticVote(type);
    }

    try {
      const result = await api.votePost(post.id, type);
      setOptimisticScore(result.score);
    } catch {
      setOptimisticScore(prevScore);
      setOptimisticVote(prevVote);
      toast.error('Failed to vote');
    }
  };

  return (
    <article className="group rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 overflow-hidden">
      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center text-white text-sm font-bold shadow-lg shadow-violet-500/10">
              {author.displayName?.[0]?.toUpperCase() ?? author.username[0]?.toUpperCase() ?? '?'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-foreground">
                  {author.displayName ?? author.username}
                </span>
                {post.isAnonymous && (
                  <span className="px-2 py-0.5 rounded-full bg-violet-500/10 text-violet-400 text-[10px] font-semibold uppercase tracking-wider">
                    Anon
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Link to={`/c/${community.slug}`} className="hover:text-primary transition-colors font-medium">
                  {community.name}
                </Link>
                <span>•</span>
                <span>{timeAgo(post.createdAt)}</span>
              </div>
            </div>
          </div>

          <button onClick={() => setShowMenu(!showMenu)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground transition-colors cursor-pointer">
            <MoreHorizontal size={16} />
          </button>
        </div>

        {/* Title */}
        {post.title && (
          <Link to={`/post/${post.id}`}>
            <h3 className="text-lg font-bold text-foreground mb-2 hover:text-primary transition-colors">
              {post.title}
            </h3>
          </Link>
        )}

        {/* Content */}
        <Link to={`/post/${post.id}`}>
          <p className="text-foreground/90 text-sm leading-relaxed whitespace-pre-wrap line-clamp-6">
            {post.content}
          </p>
        </Link>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {tags.map((tag) => (
              <span key={tag} className="px-2.5 py-1 rounded-lg bg-secondary text-muted-foreground text-xs font-medium">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Poll */}
        {poll && (
          <div className="mt-4 space-y-2">
            {poll.options.map((option) => (
              <div key={option.id} className="relative overflow-hidden rounded-xl border border-border">
                <div
                  className="absolute inset-0 bg-primary/10 transition-all"
                  style={{ width: `${option.percentage}%` }}
                />
                <div className="relative px-4 py-3 flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{option.text}</span>
                  <span className="text-xs text-muted-foreground font-semibold">{option.percentage}%</span>
                </div>
              </div>
            ))}
            <p className="text-xs text-muted-foreground">{poll.totalVotes} votes</p>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-1 mt-4 -ml-2">
          {/* Vote */}
          <div className="flex items-center rounded-xl bg-secondary border border-border">
            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={() => handleVote('UP')}
              className={cn(
                'p-2 rounded-l-xl transition-colors cursor-pointer',
                optimisticVote === 'UP' ? 'text-violet-400 bg-violet-500/10' : 'text-muted-foreground hover:text-violet-400'
              )}
            >
              <ArrowUp size={18} strokeWidth={2.5} />
            </motion.button>
            <span className={cn(
              'px-2 text-sm font-bold min-w-[2rem] text-center',
              optimisticScore > 0 ? 'text-violet-400' : optimisticScore < 0 ? 'text-red-400' : 'text-muted-foreground'
            )}>
              {formatNumber(optimisticScore)}
            </span>
            <motion.button
              whileTap={{ scale: 0.85 }}
              onClick={() => handleVote('DOWN')}
              className={cn(
                'p-2 rounded-r-xl transition-colors cursor-pointer',
                optimisticVote === 'DOWN' ? 'text-red-400 bg-red-500/10' : 'text-muted-foreground hover:text-red-400'
              )}
            >
              <ArrowDown size={18} strokeWidth={2.5} />
            </motion.button>
          </div>

          {/* Comments */}
          <Link to={`/post/${post.id}`} className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground transition-all text-sm">
            <MessageSquare size={16} />
            <span className="font-medium">{post.commentCount}</span>
          </Link>

          {/* Share */}
          <button
            onClick={() => { navigator.clipboard.writeText(`${window.location.origin}/post/${post.id}`); toast.success('Link copied!'); }}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-muted-foreground hover:bg-secondary hover:text-foreground transition-all text-sm cursor-pointer"
          >
            <Share2 size={16} />
          </button>
        </div>
      </div>
    </article>
  );
}
