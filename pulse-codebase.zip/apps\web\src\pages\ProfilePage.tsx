import { useAuthStore } from '../stores/auth-store';
import { motion } from 'framer-motion';
import { Mail, GraduationCap, Calendar, MessageSquare, FileText, Settings, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function ProfilePage() {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();

  if (!user) return null;

  const stats = [
    { label: 'Posts', value: user._count?.posts ?? '—', icon: FileText },
    { label: 'Comments', value: user._count?.comments ?? '—', icon: MessageSquare },
  ];

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-20 md:pb-6">
      {/* Profile Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-card border border-border overflow-hidden"
      >
        <div className="h-28 bg-gradient-to-r from-violet-600 via-purple-600 to-fuchsia-600" />
        <div className="px-6 pb-6 -mt-10">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-violet-400 to-fuchsia-500 flex items-center justify-center text-white text-3xl font-black shadow-xl border-4 border-card">
            {user.displayName?.[0]?.toUpperCase() ?? user.username[0]?.toUpperCase()}
          </div>

          <div className="mt-4">
            <h1 className="text-2xl font-bold text-foreground">{user.displayName ?? user.username}</h1>
            <p className="text-muted-foreground">@{user.username}</p>
            {user.bio && <p className="text-sm text-foreground/85 mt-2">{user.bio}</p>}
          </div>

          <div className="grid grid-cols-2 gap-4 mt-6">
            {stats.map((stat) => (
              <div key={stat.label} className="p-4 rounded-xl bg-secondary border border-border">
                <div className="flex items-center gap-2 text-muted-foreground mb-1">
                  <stat.icon size={14} />
                  <span className="text-xs font-medium">{stat.label}</span>
                </div>
                <p className="text-2xl font-bold text-foreground">{stat.value}</p>
              </div>
            ))}
          </div>

          <div className="space-y-3 mt-6">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Mail size={16} /><span>{user.email}</span>
            </div>
            {user.college && (
              <div className="flex items-center gap-3 text-sm text-muted-foreground">
                <GraduationCap size={16} /><span>{user.college} {user.branch ? `• ${user.branch}` : ''} {user.year ? `• Year ${user.year}` : ''}</span>
              </div>
            )}
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Calendar size={16} /><span>Member since {new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</span>
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <button className="flex-1 py-2.5 rounded-xl bg-secondary border border-border text-foreground font-medium flex items-center justify-center gap-2 text-sm hover:bg-muted transition-all cursor-pointer">
              <Settings size={16} />Edit Profile
            </button>
            <button
              onClick={async () => { await logout(); navigate('/login'); }}
              className="py-2.5 px-4 rounded-xl border border-red-500/20 text-red-400 font-medium flex items-center justify-center gap-2 text-sm hover:bg-red-500/10 transition-all cursor-pointer"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
