import type { ApiResponse, PaginatedResponse } from '@pulse/shared';

const API_URL = '/api';

class ApiClient {
  private token: string | null = null;

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('pulse-token', token);
    } else {
      localStorage.removeItem('pulse-token');
    }
  }

  getToken(): string | null {
    if (!this.token) {
      this.token = localStorage.getItem('pulse-token');
    }
    return this.token;
  }

  private async request<T>(path: string, options: RequestInit = {}): Promise<T> {
    const token = this.getToken();
    const headers: Record<string, string> = {
      ...((options.headers as Record<string, string>) ?? {}),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    if (!(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }

    const res = await fetch(`${API_URL}${path}`, {
      ...options,
      headers,
    });

    const data = await res.json() as ApiResponse<T>;

    if (!res.ok) {
      throw new Error(data.error ?? `Request failed with status ${res.status}`);
    }

    return data.data as T;
  }

  // Auth
  async register(body: Record<string, unknown>) {
    return this.request<{ user: Record<string, unknown>; token: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async login(body: Record<string, unknown>) {
    return this.request<{ user: Record<string, unknown>; token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async logout() {
    return this.request('/auth/logout', { method: 'POST' });
  }

  async getMe() {
    return this.request<Record<string, unknown>>('/auth/me');
  }

  async updateProfile(body: Record<string, unknown>) {
    return this.request('/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify(body),
    });
  }

  // Posts
  async getFeed(params: Record<string, string> = {}) {
    const search = new URLSearchParams(params).toString();
    return this.request<PaginatedResponse<Record<string, unknown>>>(`/posts?${search}`);
  }

  async getPost(id: string) {
    return this.request<Record<string, unknown>>(`/posts/${id}`);
  }

  async createPost(body: Record<string, unknown>) {
    return this.request<Record<string, unknown>>('/posts', {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async votePost(id: string, type: 'UP' | 'DOWN') {
    return this.request<{ postId: string; score: number }>(`/posts/${id}/vote`, {
      method: 'POST',
      body: JSON.stringify({ type }),
    });
  }

  async votePoll(postId: string, optionId: string) {
    return this.request(`/posts/${postId}/poll/vote`, {
      method: 'POST',
      body: JSON.stringify({ optionId }),
    });
  }

  async deletePost(id: string) {
    return this.request(`/posts/${id}`, { method: 'DELETE' });
  }

  // Comments
  async getComments(params: Record<string, string>) {
    const search = new URLSearchParams(params).toString();
    return this.request<PaginatedResponse<Record<string, unknown>>>(`/comments?${search}`);
  }

  async createComment(body: Record<string, unknown>) {
    return this.request<Record<string, unknown>>('/comments', {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  async voteComment(id: string, type: 'UP' | 'DOWN') {
    return this.request(`/comments/${id}/vote`, {
      method: 'POST',
      body: JSON.stringify({ type }),
    });
  }

  // Communities
  async getCommunities(college?: string) {
    const search = college ? `?college=${encodeURIComponent(college)}` : '';
    return this.request<Record<string, unknown>[]>(`/communities${search}`);
  }

  async getCommunity(slug: string) {
    return this.request<Record<string, unknown>>(`/communities/${slug}`);
  }

  async joinCommunity(id: string) {
    return this.request(`/communities/${id}/join`, { method: 'POST' });
  }

  async leaveCommunity(id: string) {
    return this.request(`/communities/${id}/leave`, { method: 'POST' });
  }

  // Notifications
  async getNotifications(params: Record<string, string> = {}) {
    const search = new URLSearchParams(params).toString();
    return this.request<PaginatedResponse<Record<string, unknown>>>(`/notifications?${search}`);
  }

  async getUnreadCount() {
    return this.request<{ count: number }>('/notifications/unread-count');
  }

  async markNotificationRead(id: string) {
    return this.request(`/notifications/${id}/read`, { method: 'POST' });
  }

  async markAllRead() {
    return this.request('/notifications/read-all', { method: 'POST' });
  }

  // Search
  async search(params: Record<string, string>) {
    const search = new URLSearchParams(params).toString();
    return this.request<Record<string, unknown>>(`/search?${search}`);
  }

  // Reports
  async createReport(body: Record<string, unknown>) {
    return this.request('/admin/reports', {
      method: 'POST',
      body: JSON.stringify(body),
    });
  }

  // Upload
  async uploadFile(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    return this.request<{ url: string; filename: string }>('/upload', {
      method: 'POST',
      body: formData,
    });
  }
}

export const api = new ApiClient();
