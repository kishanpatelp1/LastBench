import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Eye, EyeOff, X } from 'lucide-react';
import { api } from '../../lib/api-client';
import { useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '../../stores/auth-store';
import { toast } from 'sonner';

export function PostComposer() {
  const { user } = useAuthStore();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [content, setContent] = useState('');
  const [title, setTitle] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [communityId, setCommunityId] = useState('');

  const handleSubmit = async () => {
    if (!content.trim() || !communityId) {
      toast.error('Please fill in content and select a community');
      return;
    }

    setIsSubmitting(true);
    try {
      await api.createPost({
        content: content.trim(),
        title: title.trim() || undefined,
        communityId,
        isAnonymous,
        type: 'TEXT',
      });
      setContent('');
      setTitle('');
      setIsOpen(false);
      queryClient.invalidateQueries({ queryKey: ['feed'] });
      toast.success('Post created! 🎉');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to create post');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="rounded-2xl bg-card border border-border overflow-hidden">
      {/* Collapsed state */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="w-full p-4 flex items-center gap-3 hover:bg-secondary/50 transition-colors cursor-pointer"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center text-white text-sm font-bold">
            {user?.displayName?.[0]?.toUpperCase() ?? '?'}
          </div>
          <span className="text-muted-foreground text-sm">What's on your mind?</span>
        </button>
      )}

      {/* Expanded state */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="p-5 space-y-4"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-foreground">Create Post</h3>
              <button onClick={() => setIsOpen(false)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground cursor-pointer">
                <X size={18} />
              </button>
            </div>

            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Title (optional)"
              className="w-full px-4 py-2.5 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            />

            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Share your thoughts..."
              rows={4}
              className="w-full px-4 py-3 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none text-sm"
            />

            <input
              value={communityId}
              onChange={(e) => setCommunityId(e.target.value)}
              placeholder="Community ID (paste from /communities page)"
              className="w-full px-4 py-2.5 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary text-sm"
            />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsAnonymous(!isAnonymous)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all cursor-pointer ${
                    isAnonymous
                      ? 'bg-violet-500/10 text-violet-400 border border-violet-500/20'
                      : 'bg-secondary text-muted-foreground border border-border'
                  }`}
                >
                  {isAnonymous ? <EyeOff size={16} /> : <Eye size={16} />}
                  {isAnonymous ? 'Anonymous' : 'Public'}
                </button>
              </div>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleSubmit}
                disabled={isSubmitting || !content.trim()}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white font-semibold flex items-center gap-2 text-sm disabled:opacity-50 hover:shadow-lg hover:shadow-violet-500/25 transition-all cursor-pointer"
              >
                {isSubmitting ? (
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <Send size={16} />
                )}
                Post
              </motion.button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
